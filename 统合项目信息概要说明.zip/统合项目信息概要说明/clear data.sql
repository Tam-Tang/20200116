﻿-- 達成率(産出)看板
delete from TH_PRO_LINE_ACH_RATE
delete from TH_EACH_SITE_WIP

--訂單看板
delete from TH_ORDER_DELIVERY_RECORD
delete from TH_ORDER_PRO_QUANTITY
delete from TH_ORDER_CYCLE_TIMEOUT
delete from TH_UNDELIVERED_DETAILS

--質量看板
delete from TH_YIELD_OF_PRO_LINE
delete from TH_DIRECT_PASS_RATE
delete from TH_PRO_LINE_DEFECT_DETAILS

--抛料率(物料)看板
delete from TH_MACHINE_THROWING_RATE

--溫濕度ESD看板
delete from TH_REAL_TIME_TEM_AND_HUM
delete from TH_ESD_REAL_TIME

--工序狀態看板
delete from TH_EUIPMENT_STATUS

--維修看板
delete from TH_MAINTENANCE_NUMBER 
delete from TH_MAINTENANCE_DETAIL
delete from TH_MAINTENANCE_CYCLE
delete from TH_TWOREFLUX
delete from TH_VENEER_WIP

--自动化看板
delete from TH_AUTO_STATUS
delete from TH_AUTO_MACHINE_INFO


